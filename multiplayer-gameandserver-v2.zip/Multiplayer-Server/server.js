// Importing the required modules
const WebSocketServer = require('ws');
var serverPort = 2002;

// Creating a new websocket server
const server = new WebSocketServer.Server({ port: serverPort })
var players = [];
var clientID = 0;
var log = 0;

function stateUpdate(){
    for(let i in players){
        var playerInfoStateUpdate = {
            id: players[i].id,
            name: players[i].name,
            x: players[i].x,
            y: players[i].y,
            state: players[i].state,
            dirx: players[i].dirx,
            playerColor: players[i].playerColor,
            playerText: players[i].playerText,
            eventName: "state_update",
        }

        //recieved player info > sending to all other clients
        for (let j in players){
            players[j].socketObject.send(JSON.stringify(playerInfoStateUpdate));
        }
    }
    setTimeout(stateUpdate,16);
}
stateUpdate();

server.on("connection", ws => 
{
    ws.clientID = clientID;
	//code that should execute just after the player connects
    console.log("Player Connected!");

    //when the client sends us a message
    ws.on("message", data => 
    {
      //  console.log(`Client has sent us: ${data}`);
        var realData = JSON.parse(data);
        var eventName = realData.eventName;

        switch(eventName)
        {
            case "create_player_request":
            clientID++;
            ws.clientID = clientID;
            var player = 
            {
                id: clientID,
                name: realData.name,
                x: 0,
                y: 0,
                state: realData.state,
                playerText: realData.playerText,
                playerColor: realData.playerColor,
                dirx: 1,
                socketObject: ws,
            }
            players.push(player);
          //  console.table(players);

            //tell client that server has succesfully created the player & stats
            ws.send(
                JSON.stringify({
                    eventName: "created_you",
                    id: clientID,
                })
            );
            break;

            case "player_update":

                for (let i in players){
                    if (players[i].id == realData.id){
                        players[i].name = realData.name;
                        players[i].x = realData.x;
                        players[i].y = realData.y;
                        players[i].state = realData.state;
                        players[i].dirx = realData.dirx;
                        players[i].playerColor = realData.playerColor;
                        players[i].playerText = realData.playerText;
                    }
                }
                
                log++ 
                if (log > 50){
               console.table(players);
                log = 0;
                }
            break;

            case "send_chat":
            var chat_string = realData.chatText;
            var typing_user = realData.typingUser;

            //console.log(chat_string);
            var stringToSend =
            {
                eventName: "recieve_chat",
                chatText: chat_string,
                typingUser: typing_user,
            }
            for(let i in players)
            {
                players[i].socketObject.send(JSON.stringify(stringToSend))

            }
            /*
            ------------------------------------------
            //send data to local player
            case "js_event":
            var stringRecieved = realData.example_var;    //turn variable recieved from the local player into a String

            ws.send(JSON.stringify({                      //send following table to local player
                    eventName: "gml_event",               //the event state in GML
                    example_var: stringRecieved,          //add new entry(s) to list
                    example_var: stringToRecieve,         //add new entry(s) to list
                }));
            break;
            //send data to local player
            //------------------------------------------
            
            //------------------------------------------
            //send data to all clients
            case "js_event":
            var stringToRecieve = realData.example_var;    //turn variable recieved from player into a String

            var stringToSend =                              //create a table to send to all players
            {
            eventName: "gml_event",                     //the event state in GML
            example_var: stringToRecieve,                   //add new entry(s) to list
            example_var: stringToRecieve,                   //add new entry(s) to list
            }
            for(let i in players)                           //check how many players there currently is
            {
            players[i].socketObject.send(
                JSON.stringify(stringToSend))               //send above table to all players
            }
            break;
            //send data to all clients
            -----------------------------------------
            */

            break;

            default:
            break;
        }

    })
    //client disconnects from server
    ws.on("close", () => 
    { 
    console.log("Player Disconnected!");
    var clientWhoDisconnected = ws.clientID;
    var stringToSend = 
    {
        name: clientWhoDisconnected,
        eventName: "destroy_player",
    }
    for(let i in players)
    {
        players[i].socketObject.send(JSON.stringify(stringToSend))
        if(players[i].id == clientWhoDisconnected)
        {
            players.splice(i,1);
        }
    }
    
    })

    //handling client connection error
    ws.onerror = function () 
    {
        console.log("An Error Occurred!!!");

    }
});
console.log("The WebSocket server is running");